<?php
include("conexion.php");

$producto = $_POST['producto'];
$proveedor = $_POST['proveedor'];
$estado = $_POST['estado'];
$cantidad = $_POST['cantidad'];
$precio_unitario_compra = $_POST['precio_unitario_compra']; // obtener precio unitario
$fecha = $_POST['fecha'];

// Calcular subtotal y total
$subtotal = $cantidad * $precio_unitario_compra;
$total = $subtotal; // Por ahora solo 1 producto, pero en el futuro será la suma de todos

//  Insertar en orden_compra
$sql1 = "INSERT INTO orden_compra (ID_proveedor, estado, total, fecha)
         VALUES ('$proveedor', '$estado', '$total', '$fecha')";

if ($conn->query($sql1) === TRUE) {
    $id_orden = $conn->insert_id;

    //  Insertar en detalle_orden_compra CON PRECIO UNITARIO Y SUBTOTAL
    $sql2 = "INSERT INTO detalle_orden_compra (ID_orden_compra, ID_producto, cantidad, precio_unitario_compra, subtotal)
             VALUES ('$id_orden', '$producto', '$cantidad', '$precio_unitario_compra', '$subtotal')";

    if ($conn->query($sql2) === TRUE) {

        //  Actualizar stock si estado es "Aprobado"
        if ($estado === 'Aprobado') {
            $sql_stock = "UPDATE producto SET stock = stock + $cantidad WHERE ID_producto = '$producto'";
            if (!$conn->query($sql_stock)) {
                echo "❌ Error al actualizar el stock del producto: " . $conn->error;
                mysqli_close($conn);
                exit;
            }
        }

        // Éxito completo
        mysqli_close($conn);
        echo "<script>
                alert('✅ Orden registrada correctamente');
                window.location='orden_compra.php';
              </script>";
        exit;

    } else {
        echo "❌ Error al insertar en detalle_orden_compra: " . $conn->error;
        mysqli_close($conn);
    }
} else {
    echo "❌ Error al insertar en orden_compra: " . $conn->error;
    mysqli_close($conn);
}
?>