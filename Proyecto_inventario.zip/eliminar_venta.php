<?php

include("conexion.php");
$codigo = $_REQUEST['id'];

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='ventas.php';</script>";
    exit();
}

// Eliminar primero el detalle asociado
$consulta_detalle = "DELETE FROM detalle_orden_venta WHERE ID_orden_venta = '$codigo'";
$conn->query($consulta_detalle);

// Luego eliminar la orden de venta
$consulta_orden = "DELETE FROM orden_venta WHERE ID_orden_venta = '$codigo'";
$conn->query($consulta_orden);

// Verificar si hubo errores
if(mysqli_connect_errno() != 0) {
    echo "Error al eliminar la venta: " . mysqli_connect_errno() . " - " . mysqli_connect_error();
    mysqli_close($conn);
} else {
    mysqli_close($conn);
    header("location:ventas.php");
    exit;
}

?>