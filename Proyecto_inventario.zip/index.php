<?php
include("conexion.php");
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="estilos.css">
    <title>Inicio de sesión</title>
</head>
<body class="custom-body d-flex justify-content-center align-items-center vh-100 bg-light">
    <div class="card shadow p-4" style="max-width: 400px; width: 100%;">
        <h1 class="text-center mb-4">Sistema de Gestión de Inventarios</h1>
        
        <form action="procesar_login.php" method="POST">
            <div class="mb-3">
                <label for="usuario" class="form-label">Documento</label>
                <input type="text" name="documento" id="usuario" class="form-control user_data" placeholder="Ingrese su documento" required>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Contraseña</label>
                <div class="input-group">
                    <input type="password" name="clave" id="password" class="form-control user_data" placeholder="Ingrese su contraseña" required>
                    <span class="input-group-text user_data" style="cursor:pointer;" onclick="mostrarContrasena()">👁</span>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary w-100 boton_login">Iniciar sesión</button>
            
        </form>
    </div>
    <script src="bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>
</html>