<?php
include("conexion.php");
session_start();

$documento = $_POST['documento'];
$clave = $_POST['clave'];

// Consulta para verificar credenciales
$sql = "SELECT * FROM usuario WHERE documento='$documento' AND clave='$clave'";
$resultado = $conn->query($sql);

if ($resultado->num_rows === 1) {
    $fila = $resultado->fetch_assoc();

    // Guardar datos en la sesión
    $_SESSION['usuario'] = $documento;
    $_SESSION['rol'] = $fila['rol']; // verificar tipo usuario
    header("Location: menu.php");
    exit();
} else {
    echo "Usuario o contraseña incorrectos. <a href='index.php'>Intentar nuevamente</a>";
}

$conn->close();
?>