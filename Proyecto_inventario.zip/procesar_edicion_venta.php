<?php
include("conexion.php");
session_start();

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// Capturar datos del formulario
$id_orden = $_POST['id_orden'];
$id_detalle = $_POST['id_detalle'];
$id_cliente = $_POST['cliente'];
$id_producto = $_POST['producto'];
$cantidad = $_POST['cantidad'];
$precio_unitario = $_POST['precio_unitario'];
$estado = $_POST['estado'];
$fecha = $_POST['fecha'];

// Calcular total
$total = $cantidad * $precio_unitario;

// Obtener información anterior de la venta (para gestionar stock)
$sql_anterior = "SELECT ov.estado, dov.ID_producto, dov.cantidad 
                 FROM orden_venta ov
                 JOIN detalle_orden_venta dov ON ov.ID_orden_venta = dov.ID_orden_venta
                 WHERE ov.ID_orden_venta = '$id_orden' AND dov.ID_detalle_venta = '$id_detalle'";
$result_anterior = $conn->query($sql_anterior);
$venta_anterior = $result_anterior->fetch_assoc();

// Actualizar tabla orden_venta
$actualizar_orden = "UPDATE orden_venta SET 
    ID_cliente = '$id_cliente',
    estado = '$estado',
    total = '$total',
    fecha = '$fecha'
    WHERE ID_orden_venta = '$id_orden'";

if ($conn->query($actualizar_orden) === TRUE) {
    
    // Actualizar tabla detalle_orden_venta
    $actualizar_detalle = "UPDATE detalle_orden_venta SET 
        ID_producto = '$id_producto',
        cantidad = '$cantidad',
        precio_unitario = '$precio_unitario'
        WHERE ID_detalle_venta = '$id_detalle'";
    
    if ($conn->query($actualizar_detalle) === TRUE) {
        
        // GESTIÓN DEL STOCK
        $estado_anterior = $venta_anterior['estado'];
        $producto_anterior = $venta_anterior['ID_producto'];
        $cantidad_anterior = $venta_anterior['cantidad'];
        
        // Caso 1: Si el estado anterior era "completada", devolver el stock del producto anterior
        if ($estado_anterior === 'completada') {
            $sql_devolver = "UPDATE producto 
                            SET stock = stock + $cantidad_anterior 
                            WHERE ID_producto = '$producto_anterior'";
            if (!$conn->query($sql_devolver)) {
                echo "❌ Error al devolver stock: " . $conn->error;
                mysqli_close($conn);
                exit;
            }
        }
        
        // Caso 2: Si el nuevo estado es "completada", descontar el stock del producto nuevo
        if ($estado === 'completada') {
            // Verificar que hay stock suficiente
            $sql_verificar = "SELECT stock FROM producto WHERE ID_producto = '$id_producto'";
            $result_stock = $conn->query($sql_verificar);
            $producto_stock = $result_stock->fetch_assoc();
            
            if ($producto_stock['stock'] < $cantidad) {
                echo "<script>
                        alert('❌ Error: Stock insuficiente. Stock disponible: {$producto_stock['stock']}');
                        window.location='ventas.php';
                      </script>";
                mysqli_close($conn);
                exit;
            }
            
            $sql_descontar = "UPDATE producto 
                             SET stock = stock - $cantidad 
                             WHERE ID_producto = '$id_producto'";
            if (!$conn->query($sql_descontar)) {
                echo "❌ Error al descontar stock: " . $conn->error;
                mysqli_close($conn);
                exit;
            }
        }
        
        // Éxito completo
        mysqli_close($conn);
        echo "<script>
                alert('✅ Venta actualizada correctamente');
                window.location='ventas.php';
              </script>";
        exit;
        
    } else {
        echo "❌ Error al actualizar detalle_orden_venta: " . $conn->error;
        mysqli_close($conn);
        exit;
    }
    
} else {
    echo "❌ Error al actualizar orden_venta: " . $conn->error;
    mysqli_close($conn);
    exit;
}
?>