<?php
include("conexion.php");
session_start();

// Verificar que sea Admin
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = $_POST['ID_usuario'];
    $nueva_clave = $_POST['nueva_clave'];

    

    // Actualizar en la base de datos
    $sql = "UPDATE usuario SET clave='$nueva_clave' WHERE ID_usuario='$id_usuario'";
    if ($conn->query($sql) === TRUE) {
        header("Location: usuarios.php?mensaje=Clave actualizada correctamente");
        exit();
    } else {
        echo "Error al actualizar la clave: " . $conn->error;
    }

    $conn->close();
} else {
    header("Location: usuarios.php");
    exit();
}
?>