<?php 
include("conexion.php");
$codigo = $_REQUEST['id'];

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='orden_compra.php';</script>";
    exit();
}

// Consulta proveedor
$resultado_prov = $conn->query("SELECT * FROM proveedor ORDER BY nombre_proveedor");

// Consulta productos
$resultado_prod = $conn->query("SELECT * FROM producto ORDER BY nombre");

// Consulta orden con JOIN incluyendo precio_unitario_compra
$sql = "
SELECT 
    oc.*,
    doc.ID_producto,
    doc.cantidad,
    doc.precio_unitario_compra,
    doc.subtotal
FROM orden_compra oc
JOIN detalle_orden_compra doc ON oc.ID_orden_compra = doc.ID_orden_compra
WHERE oc.ID_orden_compra = '$codigo'
";
$resultado = $conn->query($sql);
$fila_orden = $resultado->fetch_assoc();

// Calcular precio unitario si no existe (para órdenes antiguas)
if (!isset($fila_orden['precio_unitario_compra']) || $fila_orden['precio_unitario_compra'] == 0) {
    $fila_orden['precio_unitario_compra'] = $fila_orden['cantidad'] > 0 ? $fila_orden['total'] / $fila_orden['cantidad'] : 0;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Orden de Compra</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="registro_usuario">
<div class="registrarse">
    <h1>Modificar información de la orden</h1>

    <form action="procesar_edicion_orden.php" method="POST" class="formulario_registro">
        
        <div class="datos_registro">
            <label for="id_orden">ID Orden</label>
            <input type="text" name="id" id="id_orden" value="<?php echo $fila_orden['ID_orden_compra']; ?>" readonly>
        </div>

        <!-- Seleccionar producto -->
        <div class="datos_registro">
            <label for="producto">Producto</label>
            <select name="producto" id="producto" required>
                <option value="" disabled>[Seleccione un producto]</option>
                <?php
                while ($fila_prod = $resultado_prod->fetch_assoc()) {
                    $selected = ($fila_prod['ID_producto'] == $fila_orden['ID_producto']) ? "selected" : "";
                    echo "<option value='{$fila_prod['ID_producto']}' $selected>{$fila_prod['nombre']}</option>";
                }
                ?>
            </select>
        </div>

        <!-- Seleccionar proveedor -->
        <div class="datos_registro">
            <label for="proveedor">Proveedor</label>
            <select name="proveedor" id="proveedor" required>
                <option value="" disabled>[Seleccione un proveedor]</option>
                <?php
                while ($fila_prov = $resultado_prov->fetch_assoc()) {
                    $selected = ($fila_prov['ID_proveedor'] == $fila_orden['ID_proveedor']) ? "selected" : "";
                    echo "<option value='{$fila_prov['ID_proveedor']}' $selected>{$fila_prov['nombre_proveedor']}</option>";
                }
                ?>
            </select>
        </div>

        <!-- Estado -->
        <div class="datos_registro">
            <label for="estado">Estado</label>
            <select name="estado" id="estado" required>
                <option value="Aprobado" <?= $fila_orden['estado'] == 'Aprobado' ? 'selected' : '' ?>>Aprobado</option>
                <option value="Procesando" <?= $fila_orden['estado'] == 'Procesando' ? 'selected' : '' ?>>Procesando</option>
                <option value="cancelado" <?= $fila_orden['estado'] == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
            </select>
        </div>

        <!-- Cantidad -->
        <div class="datos_registro">
            <label for="cantidad">Cantidad</label>
            <input type="number" name="cantidad" id="cantidad" value="<?php echo $fila_orden['cantidad']; ?>" placeholder="Cantidad" required>
        </div>

        <!-- Precio Unitario de Compra -->
        <div class="datos_registro">
            <label for="precio_unitario">Precio Unitario de Compra</label>
            <input type="number" step="0.01" name="precio_unitario" id="precio_unitario" value="<?php echo $fila_orden['precio_unitario_compra']; ?>" placeholder="Ej: 45000" required>
        </div>

        <!-- Total (calculado automáticamente) -->
        <div class="datos_registro">
            <label for="total">Total (calculado)</label>
            <input type="number" name="total" id="total" value="<?php echo $fila_orden['total']; ?>" placeholder="Se calcula automáticamente" readonly style="background-color: #f0f0f0;">
        </div>

        <!-- Fecha -->
        <div class="datos_registro">
            <label for="fecha">Fecha</label>
            <input type="date" name="fecha" id="fecha" value="<?php echo $fila_orden['fecha']; ?>" required>
        </div>

        <button type="submit" class="boton_registro">Guardar cambios</button>
    </form>
</div>

<script>
    // Calcular el total automáticamente cuando cambian cantidad o precio unitario
    const cantidad = document.getElementById('cantidad');
    const precioUnitario = document.getElementById('precio_unitario');
    const total = document.getElementById('total');

    function calcularTotal() {
        const cant = parseFloat(cantidad.value) || 0;
        const precio = parseFloat(precioUnitario.value) || 0;
        const totalCalculado = cant * precio;
        total.value = Math.round(totalCalculado);
    }

    cantidad.addEventListener('input', calcularTotal);
    precioUnitario.addEventListener('input', calcularTotal);
</script>
</body>
</html>