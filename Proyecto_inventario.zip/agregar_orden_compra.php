<?php 
include("conexion.php");
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

$proveedores = $conn->query("SELECT * FROM proveedor");
$productos = $conn->query("SELECT * FROM producto");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar orden de compra</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="registro_usuario">
    <div class="registrarse">
        <h1>Información de la orden de compra</h1>
        <form action="procesar_nueva_orden.php" method="POST" class="formulario_registro">

            <!-- Producto (de la tabla producto) -->
            <div class="datos_registro">
                <label for="producto">Producto</label>
                <select name="producto" id="producto" required>
                    <option value="" disabled selected>[Seleccione una opción]</option>
                    <?php while ($p = $productos->fetch_assoc()) {
                        echo "<option value='{$p['ID_producto']}'>{$p['nombre']}</option>";
                    } ?>
                </select>
            </div>

            <!-- Proveedor -->
            <div class="datos_registro">
                <label for="proveedor">Proveedor</label>
                <select name="proveedor" id="proveedor" required>
                    <option value="" disabled selected>[Seleccione una opción]</option>
                    <?php while ($prov = $proveedores->fetch_assoc()) {
                        echo "<option value='{$prov['ID_proveedor']}'>{$prov['nombre_proveedor']}</option>";
                    }
                    mysqli_close($conn);
                    ?>
                </select>
            </div>

            <!-- Estado -->
            <div class="datos_registro">
                <label for="estado">Estado</label>
                <select name="estado" id="estado" required>
                    <option value="" disabled selected>[Seleccione una opción]</option>
                    <option value="Aprobado">Aprobado</option>
                    <option value="Procesando">Procesando</option>
                    <option value="cancelado">Cancelado</option>
                </select>
            </div>

            <!-- Cantidad -->
            <div class="datos_registro">
                <label for="cantidad">Cantidad</label>
                <input type="number" name="cantidad" id="cantidad" placeholder="Cantidad" required>
            </div>

            <!-- Precio Unitario de Compra -->
            <div class="datos_registro">
                <label for="precio_unitario">Precio Unitario de Compra</label>
                <input type="number" step="0.01" name="precio_unitario" id="precio_unitario" placeholder="Precio unitario" required>
            </div>

            <!-- Total (calculado automáticamente, solo lectura) -->
            <div class="datos_registro">
                <label for="total">Total (calculado)</label>
                <input type="number" name="total" id="total" placeholder="" readonly style="background-color: #f0f0f0;">
            </div>

            <!-- Fecha -->
            <div class="datos_registro">
                <label for="fecha">Fecha</label>
                <input type="date" name="fecha" id="fecha" required>
            </div>

            <button type="submit" class="boton_registro">Guardar orden</button>
        </form>
    </div>

    <script>
        // Calcular el total automáticamente cuando cambian cantidad o precio unitario
        const cantidad = document.getElementById('cantidad');
        const precioUnitario = document.getElementById('precio_unitario');
        const total = document.getElementById('total');

        function calcularTotal() {
            const cant = parseFloat(cantidad.value) || 0;
            const precio = parseFloat(precioUnitario.value) || 0;
            const totalCalculado = cant * precio;
            total.value = Math.round(totalCalculado);
        }

        cantidad.addEventListener('input', calcularTotal);
        precioUnitario.addEventListener('input', calcularTotal);
    </script>
</body>
</html>