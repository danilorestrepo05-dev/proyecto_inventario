<?php
include("conexion.php");
session_start();

// Solo el admin puede cambiar claves
if ($_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='usuarios.php';</script>";
    exit();
}

if (!isset($_GET['id'])) {
    echo "<script>alert('Usuario no especificado'); window.location='usuarios.php';</script>";
    exit();
}

$id_usuario = $_GET['id']; // ID del usuario a modificar

// Si el formulario fue enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nueva_clave = $_POST['nueva_clave'];

    $sql = "UPDATE usuario SET clave='$nueva_clave' WHERE ID_usuario='$id_usuario'";
    if ($conn->query($sql)) {
        header("Location: usuarios.php?mensaje=Clave actualizada correctamente");
        exit();
    } else {
        $error = "Error al actualizar la clave: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cambiar clave</title>
    <link rel="stylesheet" href="estilos.css">
    <link rel="stylesheet" href="bootstrap.min.css">
<style>
        body {
            background-color: #a0e7f0;
        }
        .card {
            max-width: 450px;
            width: 100%;
        }
        @media (max-width: 768px) {
            .card {
                margin: 0 10px; /* margen lateral pequeño en móviles */
            }
        }
    </style>
</head>
<body class="d-flex justify-content-center align-items-center min-vh-100">
    <div class="card shadow p-4">
        <h4 class="text-center mb-4">Cambiar clave del usuario: <?php echo $id_usuario; ?></h4>

        <?php if (!empty($error)) echo "<div class='alert alert-danger text-center'>$error</div>"; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="nueva_clave" class="form-label">Nueva clave</label>
                <input type="password" name="nueva_clave" id="nueva_clave" class="form-control form-control-lg" placeholder="Ingrese la nueva clave" required>
            </div>

            <button type="submit" class="btn btn-primary w-100 mb-2">Guardar nueva clave</button>
            <a href="usuarios.php" class="btn btn-outline-secondary w-100">Cancelar</a>
        </form>
    </div>

    <script src="bootstrap.bundle.min.js"></script>
</body>
</html>