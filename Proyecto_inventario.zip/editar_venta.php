<?php 
include("conexion.php");
$codigo = $_REQUEST['id'];

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='ventas.php';</script>";
    exit();
}

// Obtener la venta
$venta = $conn->query("SELECT * FROM orden_venta WHERE ID_orden_venta = '$codigo'")->fetch_assoc();

// Obtener el detalle asociado
$detalle = $conn->query("SELECT * FROM detalle_orden_venta WHERE ID_orden_venta = '$codigo'")->fetch_assoc();

// Obtener clientes
$clientes = $conn->query("SELECT * FROM cliente");

// Obtener productos
$productos = $conn->query("SELECT * FROM producto");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Venta</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="registro_usuario">
    <div class="registrarse">
        <h1>Modificar información de la venta</h1>

        <form action="procesar_edicion_venta.php" method="POST" class="formulario_registro">

            <input type="hidden" name="id_orden" value="<?= $venta['ID_orden_venta'] ?>">
            <input type="hidden" name="id_detalle" value="<?= $detalle['ID_detalle_venta'] ?>">

            <!-- Cliente -->
            <div class="datos_registro">
                <label>Cliente</label>
                <select name="cliente" required>
                    <option disabled selected>[Seleccione un cliente]</option>
                    <?php while($cli = $clientes->fetch_assoc()): ?>
                        <option value="<?= $cli['ID_cliente'] ?>" <?= $cli['ID_cliente'] == $venta['ID_cliente'] ? 'selected' : '' ?>>
                            <?= $cli['nombre'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <!-- Producto -->
            <div class="datos_registro">
                <label>Producto</label>
                <select name="producto" required>
                    <option disabled selected>[Seleccione un producto]</option>
                    <?php while($prod = $productos->fetch_assoc()): ?>
                        <option value="<?= $prod['ID_producto'] ?>" <?= $prod['ID_producto'] == $detalle['ID_producto'] ? 'selected' : '' ?>>
                            <?= $prod['nombre'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <!-- Cantidad -->
            <div class="datos_registro">
                <label>Cantidad</label>
                <input type="number" name="cantidad" value="<?= $detalle['cantidad'] ?>" placeholder="Cantidad" required>
            </div>

            <!-- Precio Unitario -->
            <div class="datos_registro">
                <label>Precio Unitario</label>
                <input type="number" step="0.01" name="precio_unitario" value="<?= $detalle['precio_unitario'] ?>" placeholder="Precio Unitario" required>
            </div>

            <!-- Estado -->
            <div class="datos_registro">
                <label>Estado</label>
                <select name="estado" required>
                    <option value="pendiente" <?= $venta['estado'] == 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                    <option value="completada" <?= $venta['estado'] == 'completada' ? 'selected' : '' ?>>Completada</option>
                    <option value="cancelada" <?= $venta['estado'] == 'cancelada' ? 'selected' : '' ?>>Cancelada</option>
                </select>
            </div>

            <!-- Fecha -->
            <div class="datos_registro">
                <input type="date" name="fecha" value="<?= $venta['fecha'] ?>" required>
            </div>

            <button type="submit" class="boton_registro">Guardar cambios</button>
        </form>
    </div>
</body>
</html>