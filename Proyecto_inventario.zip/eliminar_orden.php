<?php
include("conexion.php");

$codigo = $_REQUEST['id'];

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='orden_compra.php';</script>";
    exit();
}

// Primero eliminar los productos asociados en detalle_orden_compra
$consulta_detalle = "DELETE FROM detalle_orden_compra WHERE ID_orden_compra = '$codigo'";
$conn->query($consulta_detalle);

// Luego eliminar la orden en orden_compra
$consulta_orden = "DELETE FROM orden_compra WHERE ID_orden_compra = '$codigo'";
$conn->query($consulta_orden);

// Validar errores
if (mysqli_connect_errno() != 0) {
    echo "Error al eliminar la orden: " . mysqli_connect_error();
    mysqli_close($conn);
} else {
    mysqli_close($conn);
    header("Location: orden_compra.php");
    exit;
}
?>