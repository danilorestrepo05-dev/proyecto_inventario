<?php
include("conexion.php");
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='orden_compra.php';</script>";
    exit();
}

$id_orden = $_POST['id'];
$producto = $_POST['producto'];
$proveedor = $_POST['proveedor'];
$estado = $_POST['estado'];
$cantidad = $_POST['cantidad'];
$precio_unitario_compra = $_POST['precio_unitario_compra'];
$fecha = $_POST['fecha'];

// Calcular subtotal y total
$subtotal = $cantidad * $precio_unitario_compra;
$total = $subtotal;

// Obtener el estado anterior y producto anterior
$sql_anterior = "SELECT oc.estado, doc.ID_producto, doc.cantidad 
                 FROM orden_compra oc
                 JOIN detalle_orden_compra doc ON oc.ID_orden_compra = doc.ID_orden_compra
                 WHERE oc.ID_orden_compra = '$id_orden'";
$result_anterior = $conn->query($sql_anterior);
$orden_anterior = $result_anterior->fetch_assoc();

// Actualizar tabla orden_compra
$sql1 = "UPDATE orden_compra 
         SET ID_proveedor = '$proveedor', 
             estado = '$estado', 
             total = '$total', 
             fecha = '$fecha'
         WHERE ID_orden_compra = '$id_orden'";

if ($conn->query($sql1) === TRUE) {
    
    // Actualizar tabla detalle_orden_compra
    $sql2 = "UPDATE detalle_orden_compra 
             SET ID_producto = '$producto', 
                 cantidad = '$cantidad',
                 precio_unitario_compra = '$precio_unitario_compra',
                 subtotal = '$subtotal'
             WHERE ID_orden_compra = '$id_orden'";
    
    if ($conn->query($sql2) === TRUE) {
        
        // Gestión del stock
        $estado_anterior = $orden_anterior['estado'];
        $producto_anterior = $orden_anterior['ID_producto'];
        $cantidad_anterior = $orden_anterior['cantidad'];
        
        // Si el estado anterior era "Aprobado", revertir el stock
        if ($estado_anterior === 'Aprobado') {
            $sql_revertir = "UPDATE producto 
                            SET stock = stock - $cantidad_anterior 
                            WHERE ID_producto = '$producto_anterior'";
            $conn->query($sql_revertir);
        }
        
        // Si el nuevo estado es "Aprobado", sumar el stock
        if ($estado === 'Aprobado') {
            $sql_agregar = "UPDATE producto 
                           SET stock = stock + $cantidad 
                           WHERE ID_producto = '$producto'";
            $conn->query($sql_agregar);
        }
        
        mysqli_close($conn);
        echo "<script>alert('Orden actualizada correctamente'); window.location='orden_compra.php';</script>";
        exit;
        
    } else {
        echo "❌ Error al actualizar detalle_orden_compra: " . $conn->error;
        mysqli_close($conn);
    }
    
} else {
    echo "❌ Error al actualizar orden_compra: " . $conn->error;
    mysqli_close($conn);
}
?>