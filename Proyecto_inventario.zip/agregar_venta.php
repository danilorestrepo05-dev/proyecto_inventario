<?php 
include("conexion.php");
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// Obtener lista de productos
$productos = $conn->query("SELECT * FROM producto ORDER BY nombre");
// Obtener lista de clientes
$clientes = $conn->query("SELECT * FROM cliente ORDER BY nombre");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar nueva venta</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body class="registro_usuario">
    <div class="registrarse">
        <h1>Información de la venta a realizar</h1>
        
        <form action="procesar_nueva_venta.php" method="POST" class="formulario_registro">
            
            <div class="datos_registro">
                <label for="cliente">Cliente</label>
                <select name="cliente" id="cliente" required>
                    <option value="" disabled selected>[Seleccione un cliente]</option>
                    <?php
                        while ($fila = $clientes->fetch_assoc()) {
                            echo "<option value='{$fila['ID_cliente']}'>{$fila['nombre']} {$fila['apellido']}</option>";
                        }
                    ?>
                </select>
            </div>

            <div class="datos_registro">
                <label for="producto">Producto</label>
                <select name="producto" id="producto" onchange="mostrarPrecio()" required>
                <option value="" disabled selected>[Seleccione un producto]</option>
                <?php
                while ($fila = $productos->fetch_assoc()) {
                echo "<option value='{$fila['ID_producto']}' data-precio='{$fila['precio']}'>
                  {$fila['nombre']}
                </option>";
                }
                ?>
                </select>
            </div>

            <div class="datos_registro">
                <input type="number" name="cantidad" id="cantidad" placeholder="Cantidad" required>
            </div>

            <div class="datos_registro">
                <input type="text" name="precio_unitario" id="precio" placeholder="Precio unitario" readonly required>
            </div>

            <div class="datos_registro">
                <input type="date" name="fecha" required>
            </div>

            <div class="datos_registro">
                <select name="estado" required>
                    <option value="" disabled selected>[Seleccione estado]</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="completada">Completada</option>
                    <option value="cancelada">Cancelada</option>
                </select>
            </div>

            <button type="submit" class="boton_registro">Guardar venta</button>
        </form>
    </div>
    
<script>
function mostrarPrecio() {
  const select = document.getElementById("producto");
  const selected = select.options[select.selectedIndex];
  const precio = selected.getAttribute("data-precio");
  document.getElementById("precio").value = precio || '';
}
</script>
</body>
</html>