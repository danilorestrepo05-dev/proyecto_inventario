<?php

include("conexion.php");
$codigo = $_REQUEST['id'];

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Admin') {
    echo "<script>alert('Acceso denegado'); window.location='clientes.php';</script>";
    exit();
}

$consulta = "DELETE FROM cliente where ID_cliente = '$codigo'";
$conn->query($consulta);

if(mysqli_connect_errno() !=0)
{
    echo "Error al eliminar el cliente" . mysqli_connect_errno() . " - " . mysqli_connect_error();
    mysqli_close($conn);
} else {
    mysqli_close($conn);
    header("location:clientes.php");
    exit;

}

?>