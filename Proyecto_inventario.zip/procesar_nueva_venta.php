<?php
include("conexion.php");
session_start();

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: inicio_sesion.php");
    exit();
}

$cliente = $_POST['cliente'];
$producto = $_POST['producto'];
$cantidad = (int) $_POST['cantidad'];
$precio_unitario = (float) $_POST['precio_unitario'];
$fecha = $_POST['fecha'];
$estado = $_POST['estado'];

$subtotal = $cantidad * $precio_unitario;

// VALIDACIÓN: Si el estado es "completada", verificar stock suficiente
if ($estado === 'completada') {
    $sql_verificar = "SELECT stock, nombre FROM producto WHERE ID_producto = '$producto'";
    $result_stock = $conn->query($sql_verificar);
    $producto_info = $result_stock->fetch_assoc();
    
    if ($producto_info['stock'] < $cantidad) {
        echo "<script>
                alert('❌ Error: Stock insuficiente para completar la venta.\\n\\nProducto: {$producto_info['nombre']}\\nStock disponible: {$producto_info['stock']}\\nCantidad solicitada: $cantidad');
                window.history.back();
              </script>";
        mysqli_close($conn);
        exit();
    }
}

// Insertar en orden_venta
$sql_orden = "INSERT INTO orden_venta (ID_cliente, fecha, estado, total) 
              VALUES ('$cliente', '$fecha', '$estado', '$subtotal')";

if ($conn->query($sql_orden) === TRUE) {
    $id_orden = $conn->insert_id;
    
    // Insertar en detalle_orden_venta
    $sql_detalle = "INSERT INTO detalle_orden_venta (ID_orden_venta, ID_producto, cantidad, precio_unitario) 
                    VALUES ('$id_orden', '$producto', '$cantidad', '$precio_unitario')";
    
    if ($conn->query($sql_detalle) === TRUE) {
        
        // Descontar del stock si la venta está completada
        if ($estado === 'completada') {
            $sql_stock = "UPDATE producto 
                         SET stock = stock - $cantidad 
                         WHERE ID_producto = '$producto'";
            
            if (!$conn->query($sql_stock)) {
                echo "❌ Error al actualizar stock: " . $conn->error;
                mysqli_close($conn);
                exit();
            }
        }
        
        // Éxito completo
        mysqli_close($conn);
        echo "<script>
                alert('✅ Venta registrada correctamente');
                window.location='ventas.php';
              </script>";
        exit();
        
    } else {
        echo "❌ Error al insertar en detalle_orden_venta: " . $conn->error;
        mysqli_close($conn);
        exit();
    }
    
} else {
    echo "❌ Error al insertar en orden_venta: " . $conn->error;
    mysqli_close($conn);
    exit();
}
?>